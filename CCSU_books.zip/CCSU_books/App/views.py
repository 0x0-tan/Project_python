import json

from django.http import HttpResponse
from django.shortcuts import render, redirect
from App.models import User, Book,comment

from App import models

def login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    elif request.method == 'POST':
        #     验证输入的用户名和密码是否正确，然后存入session
        type = request.POST.get('type')
        response = {'msg': '', 'status': False}
        # 获取前端的数据
        uid = request.POST.get('uid')
        pwd = request.POST.get('pwd')
        print("111==========================",uid,pwd)
        # 统一在登陆方法中判断这个输入输出框按钮是哪种状态
        if type == 'login':
            #     登陆验证  判断用户名和密码
            if len(models.User.objects.filter(uid=uid, password=pwd)) != 0:
                #         登陆成功  -----异步实现的
                response['status'] = True
                request.session['uid'] = uid
                return HttpResponse(json.dumps(response))
            else:
                #         登陆失败的情况
                response['msg'] = '用户名或者密码错误'
                return HttpResponse(json.dumps(response))


def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    elif request.method == 'POST':
        #     验证输入的用户名和密码是否正确，然后存入session
        type = request.POST.get('type')
        response = {'msg': '', 'status': False}
        # 获取前端的数据
        uid = request.POST.get('uid')
        pwd = request.POST.get('pwd')
        print("111==========================",uid,pwd)
        # 统一在登陆方法中判断这个输入输出框按钮是哪种状态
        if type == 'register':
            if len(models.User.objects.filter(uid=uid)) == 0:
                models.User.objects.create(uid=uid, password=pwd)
                response['status'] = True
                request.session['uid'] = uid
                return HttpResponse(json.dumps(response))
            else:
                response['msg'] = '该用户已经被注册'
                return HttpResponse(json.dumps(response))

def admin(request):
    if request.method == 'GET':
        return render(request, 'my_admin.html')
    elif request.method == 'POST':
        admin_uid = request.POST.get('admin_id')
        admin_pwd = request.POST.get('admin_pwd')

        response = {'msg': '', 'status': False}
        # 唯一管理员账号
        if admin_uid == 'guanliyuan' and admin_pwd == '123456':
            response['status'] = True
            # request.session['admin_uid'] = 'guanliyuan'
            # response['msg'] = '登录成功'
            return HttpResponse(json.dumps(response))
        else:
            response['msg'] = '用户名或者密码错误'
            return HttpResponse(json.dumps(response))


def topic_manage(request):
    # 判断是不是管理登陆
    if not request.session.get('admin_uid'):
        return redirect('/my_admin')

    if request.method == 'GET':
        books = models.Book.objects.filter()
        response = {'books':books}
        return render(request,'admin_home.html',response)

#     删除帖子  推荐帖子  取消推荐
    elif request.method == 'POST':
        p_type = request.POST.get('type')
        response={'msg':'','status':False}
        print(p_type)

#       实现删除
        if p_type == 'delete':
            t_id = request.POST.get('t_id')
            models.Book.objects.filter(id=t_id).delete()
            response['status'] = True
        #     推荐
        if p_type == 'tuijian':
            t_id = request.POST.get('t_id')
            models.Book.objects.filter(id=t_id).update(recommend=True)
            response['status'] = True
        #     取消推荐
        if p_type == 'qxtuijian':
            t_id = request.POST.get('t_id')
            models.Book.objects.filter(id=t_id).update(recommend=False)
            response['status'] = True
        return HttpResponse(json.dumps(response))


    # 所有帖子


def comment_manage(request):
    # 判断是不是管理登陆
    if not request.session.get('admin_uid'):
        return redirect('/my_admin')

    # 查询板块
    if request.method == 'GET':
        comments = models.Comment.objects.filter()
        response = {'comments': comments}
        return render(request, 'comment_manage.html', response)

    #     删除  添加  类别
    elif request.method == 'POST':
        #         接收页面的请求类型
        p_type = request.POST.get('type')
        response = {'msg': '', 'status': False}
        if p_type == 'delete':
            k_id = request.POST.get('k_id')
            models.Comment.objects.filter(id=k_id).delete()
            response['status'] = True
        return HttpResponse(json.dumps(response))


def add_manage(request):
    if request.method == 'GET':
        # 根据模板查类别
        kinds = models.Kind.objects.filter()
        response = {
            'kinds': kinds
        }
        print(response)
        return render(request, 'add.html', response)
    elif request.method == 'POST':
        #     根据登陆的信息获取uid
        #     uid = request.session.get('uid')
        # 当点击提交时提交到数据的信息
        b_name = request.POST.get('b_name')
        b_author = request.POST.get('b_author')
        b_introduction = request.POST.get('b_introduction')
        b_content = request.POST.get('b_content')
        b_kind = request.POST.get('b_kind')
        # 数据获取完成
        #   print(t_title, t_introduce, t_content, t_kind)

        obj = models.Book.objects.create(b_name=b_name, b_author=b_author,
                                         b_introduction=b_introduction, b_content=b_content,
                                         b_kind=b_kind
                                          )
        # t_id = obj.id
        # #     进行图片处理
        # b_photo = request.FILES.get('b_photo', None)
        # b_photo_path = 'static/img/t_photo/' + str(t_id) + '_' + b_photo.name
        #
        # if b_photo:
        #     import os
        #     file = open(os.path.join(b_photo_path), 'wb')
        #     for line in b_photo.chunks():
        #         file.write(line)
        #     file.close()
        #
        # #     执行数据库的更新语句将数据存入
        # models.Book.objects.filter(id=t_id).update(b_photo='/' + b_photo_path)
        return HttpResponse("发布成功")

def book_message(request, book_num):
    book_obj = Book.objects.get(id=book_num)
    param_dict = {}.fromkeys(('author', 'kind', 'introduction', 'photo', 'likes', 'content', 'name', 'id','comment_li'))
    param_dict['comment_li'] = comment.objects.filter(c_bname=book_obj.b_name)
    param_dict['id'] = book_num
    param_dict['name'] = book_obj.b_name
    param_dict['author'] = book_obj.b_author
    param_dict['kind'] = book_obj.b_kind
    param_dict['introduction'] = book_obj.b_introduction
    #photo是一个图片链接
    param_dict['photo'] = book_obj.b_photo
    param_dict['likes'] = book_obj.b_likes
    # content内容的链接
    param_dict['content'] = book_obj.b_content

    return render(request, 'book.html', context=param_dict)


def book_likes(request, b_id):
    book_obj = Book.objects.get(id=b_id)
    param_dict = {}.fromkeys(('author', 'kind', 'introduction', 'photo', 'likes', 'content', 'name', 'id','comment_li'))
    book_obj.b_likes += 1
    book_obj.save()
    print('likes add successful')
    book_obj = Book.objects.get(id=b_id)
    param_dict['comment_li'] = comment.objects.filter(c_bname=book_obj.b_name)
    param_dict['likes'] = book_obj.b_likes
    param_dict['id'] = b_id
    param_dict['name'] = book_obj.b_name
    param_dict['author'] = book_obj.b_author
    param_dict['kind'] = book_obj.b_kind
    param_dict['introduction'] = book_obj.b_introduction
    # photo是一个图片链接
    param_dict['photo'] = book_obj.b_photo
    # content内容的链接
    param_dict['content'] = book_obj.b_content

    return render(request, 'book.html', context=param_dict)


def book_classify(request, kind):
    books = Book.objects.filter(b_kind=kind)
    print(kind)
    if kind == 'china':
        return render(request, 'china.html', context={'book_li': books})
    elif kind == 'foreign':
        return render(request, 'foreign.html', context={'book_li':books})
    return render(request, 'foreign.html', context={'book_li': books})


def book_submit(request, book_id):
    book_obj = Book.objects.get(id=book_id)
    param_dict = {}.fromkeys(('author', 'kind', 'introduction', 'photo', 'likes', 'content', 'name', 'id', 'comment_li'))
    param_dict['comment_li'] = comment.objects.filter(c_bname=book_obj.b_name)
    param_dict['id'] = book_id
    param_dict['name'] = book_obj.b_name
    param_dict['author'] = book_obj.b_author
    param_dict['kind'] = book_obj.b_kind
    param_dict['introduction'] = book_obj.b_introduction
    # photo是一个图片链接
    param_dict['photo'] = book_obj.b_photo
    param_dict['likes'] = book_obj.b_likes
    # content内容的链接
    param_dict['content'] = book_obj.b_content

    if request.method == 'POST':
        r_content = request.POST.get('r_content')


    #不知道如何获取用户名和时间
        comment.objects.create(c_bname=param_dict['name'],c_uid=10,c_content=r_content,c_time=0)

    return render(request, 'book.html', context=param_dict)


def book_randing(request):
    book_obj = Book.objects.all()
    list1 = []
    list2 = []
    for item in book_obj:
        list1.append(item.b_likes)
    list1.sort()
    list1.reverse()
    print(list1)
    for b_sort in list1:
        for item in book_obj:
            if item.b_likes == b_sort and item not in list2:
                list2.append(item)
                break

    return render(request, 'rank.html', context={'book_li': list2})

def library_home(request):
    if request.method == 'GET':
        response={}
        # top10 书本推荐
    books = Book.objects.filter(recommend=True)
    # 容器列表
    b_list = []
    for b in books:
        dic={'b_id':b.id,'b_author':b.b_author,'b_name':b.b_name,'b_photo':b.b_photo}
        print(dic)
        b_list.append(dic)
    response['b_list'] = b_list

    # 将登陆的UID装入回复字典中
    # response['uid'] = request.session['uid']

    # 将所有类别放入回复字典
    return render(request,'library_home.html', context=response)


