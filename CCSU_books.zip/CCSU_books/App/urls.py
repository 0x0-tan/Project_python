from django.contrib import admin
from django.urls import path, re_path
from App import views
import re

urlpatterns = [
    path('login/', views.login,name='login'),
    path('register/', views.register,name='register'),
    path('my_admin', views.admin,name='admin'),
    path('admin_home/',views.topic_manage,name='topic_manage'),
    path('comment_manage/',views.comment_manage,name='comment_manage'),
    path('add_manage/',views.add_manage,name='add_manage'),
    path('library_home/', views.library_home, name='library_home'),
    path('book/<int:book_num>', views.book_message, name='book_message'),
    path('book_likes/<int:b_id>', views.book_likes, name='book_likes'),
    path('submit/<int:book_id>', views.book_submit, name='book_submit'),
    path('book_randing/', views.book_randing, name='book_randing'),
    path('classify/<path:kind>', views.book_classify, name='book_classify'),
]
