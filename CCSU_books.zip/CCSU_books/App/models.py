from django.db import models

# Create your models here.

class User(models.Model):
    uid = models.CharField(verbose_name='电话/用户号',max_length=16,unique=True)
    password = models.CharField(verbose_name='密码',max_length=16)
    create_time = models.DateTimeField(verbose_name='创建时间',auto_now_add=True)

    class Meta:
        db_table='user'


class Manager(models.Model):
    mid = models.CharField(verbose_name='电话/用户号', max_length=16, unique=True)
    password = models.CharField(verbose_name='密码', max_length=16)

    class Meta:
        db_table = 'manager'

class Kind(models.Model):
    k_name = models.CharField(verbose_name='类别',max_length=16,unique=True)

    class Meta:
        db_table='kind'

class Book(models.Model):
    b_name = models.CharField(verbose_name='图书名称',max_length=64,unique=True)
    b_author = models.CharField(verbose_name='作者',max_length=64,null=True)
    b_kind = models.CharField(verbose_name='图书类别',max_length=64,null=True)
    b_introduction = models.CharField(verbose_name='图书简介',max_length=255,null=True)
    b_photo = models.CharField(verbose_name='图书图片', max_length=128, null=True)
    b_likes = models.IntegerField(verbose_name='点赞数量',default=0)
    b_content = models.CharField(verbose_name='图书内容',max_length=255,null=True) #这里存的是一个图书的链接
    recommend = models.BooleanField(verbose_name='是否推荐', default=False)

    class Meta:
        db_table='book'



class comment(models.Model):
    # 没有外键的关系  联合查询
    c_bname =models.CharField(verbose_name='所属书名',max_length=16)
    c_uid=models.CharField(verbose_name='评论者id',max_length=16)
    c_content = models.CharField(verbose_name='评论内容',max_length=255)
    c_time = models.DateField(verbose_name='评论时间',auto_now_add=True)

    class Meta:
        db_table='reply'
